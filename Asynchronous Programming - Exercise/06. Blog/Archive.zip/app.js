function attachEvents() {
    
    const loadPostBtn = document.getElementById('btnLoadPosts');
    const viewPostBtn = document.getElementById('btnViewPost');
    const select = document.getElementById('posts');


    loadPostBtn.addEventListener('click', loadPosts);
    viewPostBtn.addEventListener('click', viewPost);



    async function loadPosts(){
        const url = `http://localhost:3030/jsonstore/blog/posts`;
        const response = await fetch(url);
        const data = await response.json();

        Object.values(data).forEach(post => {
            const option = document.createElement('option');
            option.value = post.id;
            option.textContent = post.title;
            select.appendChild(option);
        })
    }; 

    async function viewPost(){
        const selectedPost = select.value;
        const url = `http://localhost:3030/jsonstore/blog/posts/${selectedPost}`;

        const response = await fetch(url);
        const data = await response.json();

        const postTitle = document.getElementById('post-title');
        const postBody = document.getElementById('post-body');

        postTitle.textContent = data.title;
        postBody.textContent = data.body;

        const commentsUrl = `http://localhost:3030/jsonstore/blog/comments`;
        const commentsResponse = await fetch(commentsUrl);
        const commentsData = await commentsResponse.json();

        const commentsUl = document.getElementById('post-comments');

        Object.values(commentsData).forEach(comment => {
            if(comment.postId === selectedPost){
                const li = document.createElement('li');
                li.textContent = comment.text;
                commentsUl.appendChild(li);
            }
        })
    };
}

attachEvents();