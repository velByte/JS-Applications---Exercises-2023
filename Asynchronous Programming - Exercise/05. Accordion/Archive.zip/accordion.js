function solution() {
    const mainSection = document.getElementById("main");

    const baseUrl = "http://localhost:3030/jsonstore/advanced/articles/list";

    fetch(baseUrl)
    .then(res => res.json())
    .then(dataFormated => {
        dataFormated.forEach(item => {
            let {_id, title} = item;
            createAccordianClass(title, _id)
        })
    })
    .catch(err => console.log(err))

    function createAccordianClass(titel, id){

        const extraUrl = `http://localhost:3030/jsonstore/advanced/articles/details/${id}`;

        fetch(extraUrl)
        .then(respones => respones.json())
        .then(data => {
            const extra = data.content;
            const accordionDiv = document.createElement("div"); 
            accordionDiv.classList.add("accordion");
    
            const headDiv = document.createElement("div");
            headDiv.classList.add("head");
            accordionDiv.appendChild(headDiv);
    
            const extraDiv = document.createElement("div"); 
            extraDiv.classList.add("extra");
            accordionDiv.appendChild(extraDiv);
    
            const titelSpan = document.createElement("span"); 
            titelSpan.textContent = titel; 
            headDiv.appendChild(titelSpan); 
    
            const moreBtn = document.createElement("button"); 
            moreBtn.classList.add("button");
            moreBtn.id = id; 
            moreBtn.textContent = "MORE"
            moreBtn.addEventListener("click", moreBtnClickHendler); 
            headDiv.appendChild(moreBtn);
    
            const extraP = document.createElement("p"); 
            extraP.textContent = extra; 
            extraDiv.appendChild(extraP);
    
            function moreBtnClickHendler(event){
                if(extraDiv.classList.contains("extra")){
                    extraDiv.classList.remove("extra");
                    moreBtn.textContent = "LESS"
                } else {
                    extraDiv.classList.add("extra");
                    moreBtn.textContent = "MORE"
                }
            }
    
            console.log(accordionDiv);

            mainSection.appendChild(accordionDiv);
        })
        .catch(err => console.log(err));

        
    }

}

solution();