function attachEvents() {
  const getWetherBtn = document.querySelector("#submit");
  const location = document.querySelector("#location");
  const forecastDiv = document.querySelector("#forecast");
  const currentDiv = document.querySelector("#current");
  const upcomingDiv = document.querySelector("#upcoming");

  const conditionSymbols = {
    "Sunny": "&#x2600;",
    "Partly sunny": "&#x26C5;",
    "Overcast": "&#x2601;",
    "Rain": "&#x2614;",
    "Degrees": "&#176;",
  };

  getWetherBtn.addEventListener("click", getWetherHendler);

  function getWetherHendler(event) {
    let currentLocation = location.value;
    main();
    async function main(){
        try {
            let first = await fetch(`http://localhost:3030/jsonstore/forecaster/locations`)
            first = await first.json();
            let code = undefined; 

            const info = first.find(item => item.name === currentLocation);
            if(info === undefined){
                throw new Error("No match found");
            }
            code = info.code;

            const [today, upcoming] = await Promise.all([
                getCurrentConditions(code),
                get3Days(code)
            ]);

            build3DaysForcast(upcoming);
            buildCurrentCondition(today);
            forecastDiv.style.display = "block";

        } catch (error) {
            displayError();
        }

    }
  }

  async function getCurrentConditions(code) {
        const response = await fetch(`http://localhost:3030/jsonstore/forecaster/today/${code}`);
        const data = await response.json();
        return data;  
  }

  async function get3Days(code) {
        const response = await fetch(`http://localhost:3030/jsonstore/forecaster/upcoming/${code}`);
        const data = await response.json(); 
        return data;
    }
  

  function build3DaysForcast(data) {
    const { forecast, name } = data;
    try {
      const mainDiv = document.createElement("div");
      mainDiv.classList.add("forecast-info");
      upcomingDiv.appendChild(mainDiv);
      for (let item in forecast) {
        let condition = forecast[item].condition;
        let high = forecast[item].high;
        let low = forecast[item].low;

        let upcomingSpan = document.createElement("span");

        let symbolSpan = document.createElement("span");
        let forcastDataSpan1 = document.createElement("span");
        let forcastDataSpan2 = document.createElement("span");

        upcomingSpan.classList.add("upcoming");
        symbolSpan.classList.add("symbol");
        forcastDataSpan1.classList.add("forecast-data");
        forcastDataSpan2.classList.add("forecast-data");

        symbolSpan.innerHTML = conditionSymbols[condition];
        forcastDataSpan1.innerHTML = `${low}${conditionSymbols["Degrees"]}/${high}${conditionSymbols["Degrees"]}`;
        forcastDataSpan2.innerHTML = `${condition}`;

        upcomingSpan.appendChild(symbolSpan);
        upcomingSpan.appendChild(forcastDataSpan1);
        upcomingSpan.appendChild(forcastDataSpan2);

        mainDiv.appendChild(upcomingSpan);
      }
    } catch (error) {
      displayError();
    }
  }

  function buildCurrentCondition(data) {
    const { condition, high, low} = data.forecast;
    const fullLocationName = data.name;
    try {

      const mainDiv = document.createElement("div");
      const symbolSpan = document.createElement("span");
      const conditionSpan = document.createElement("span");
      const spanDate1 = document.createElement("span");
      const spanDate2 = document.createElement("span");
      const spanDate3 = document.createElement("span");

      mainDiv.classList.add("forecasts");
      symbolSpan.classList.add("condition");
      symbolSpan.classList.add("symbol");
      conditionSpan.classList.add("condition");
      spanDate1.classList.add("forecast-data");
      spanDate2.classList.add("forecast-data");
      spanDate3.classList.add("forecast-data");

      symbolSpan.innerHTML = conditionSymbols[condition];
      spanDate1.textContent = fullLocationName;
      spanDate2.innerHTML = `${low}${conditionSymbols["Degrees"]}/${high}${conditionSymbols["Degrees"]}`;
      spanDate3.textContent = condition;

      conditionSpan.appendChild(spanDate1);
      conditionSpan.appendChild(spanDate2);
      conditionSpan.appendChild(spanDate3);

      mainDiv.appendChild(symbolSpan);
      mainDiv.appendChild(conditionSpan);

      currentDiv.appendChild(mainDiv);
    } catch (error) {
      displayError();
    }
  }

  function displayError() {
    forecastDiv.style.display = "block";
    currentDiv.querySelector(".label").innerHTML = "Error";
  }
}
attachEvents();